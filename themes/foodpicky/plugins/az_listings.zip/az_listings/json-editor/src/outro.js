  window.JSONEditor = JSONEditor;
})();
